package com.kingdom_rush.model;

public enum RaiderType {
    SPEED, SHIELD, FLY, SHOOT
}
